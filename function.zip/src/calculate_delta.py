from datetime import datetime, timedelta
import boto3

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("ExchangeRates")

def get_rates_with_delta():
    today = datetime.utcnow().strftime("%Y-%m-%d")
    yesterday = (datetime.utcnow() - timedelta(days=1)).strftime("%Y-%m-%d")

    today_rates = fetch_rates_by_date(today)
    yesterday_rates = fetch_rates_by_date(yesterday)

    result = []
    for currency, today_rate in today_rates.items():
        yesterday_rate = yesterday_rates.get(currency, None)
        change = today_rate - yesterday_rate if yesterday_rate else None
        result.append({
            "currency": currency,
            "rate": today_rate,
            "change": change
        })
    return result

def fetch_rates_by_date(date):
    response = table.query(
        IndexName="currency_code-index",
        KeyConditionExpression="date = :date",
        ExpressionAttributeValues={":date": date}
    )
    return {item["currency_code"]: item["rate"] for item in response.get("Items", [])}
