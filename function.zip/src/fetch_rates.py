import requests
import boto3
from datetime import datetime

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("ExchangeRates")

def fetch_exchange_rates():
    url = "https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml"
    response = requests.get(url)
    response.raise_for_status()
    data = response.text
    return parse_rates(data)

def parse_rates(data):
    # Parsing XML data (simplified)
    from xml.etree import ElementTree
    tree = ElementTree.fromstring(data)
    namespace = {"ns": "http://www.ecb.int/vocabulary/2002-08-01/eurofxref"}
    rates = {}
    for cube in tree.findall(".//ns:Cube[@currency]", namespace):
        rates[cube.attrib["currency"]] = float(cube.attrib["rate"])
    return rates

def store_exchange_rates():
    rates = fetch_exchange_rates()
    for currency, rate in rates.items():
        table.put_item(
            Item={
                "currency_code": currency,
                "date": datetime.utcnow().strftime("%Y-%m-%d"),
                "rate": rate
            }
        )